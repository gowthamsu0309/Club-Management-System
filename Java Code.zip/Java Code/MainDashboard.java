import javax.swing.*;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;


public class MainDashboard extends JFrame {

    private final CurrentUser currentUser;

    public MainDashboard(CurrentUser currentUser) {
        this.currentUser = currentUser;

        setTitle("Club Management System");
        setSize(480, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(240, 244, 250), new Color(214, 224, 240)));

        String subtitle = currentUser.getName() + " (" + currentUser.getRole() + ")";
        add(headerWithSubtitle("Club Management System", subtitle), BorderLayout.NORTH);
        
        JPanel page = UIStyle.imageBackgroundFromMain("manage.png");
        setContentPane(page);
        
        GridBagConstraints outer = new GridBagConstraints();
        outer.gridx = 0;
        outer.gridy = 0;

        JPanel menu = new JPanel();
        menu.setOpaque(false);
        menu.setBorder(BorderFactory.createEmptyBorder(24, 40, 24, 40));
        
menu.setLayout(new BoxLayout(menu, BoxLayout.Y_AXIS));

Dimension buttonSize = new Dimension(280, 45);

JButton[] buttons = {
    menuButton("Manage Clubs", new Color(41, 98, 255), () -> openModule(new ClubForm(currentUser))),
    menuButton("Manage Students", new Color(46, 160, 67), () -> openModule(new StudentForm(currentUser))),
    menuButton("Manage Staff", new Color(255, 152, 0), () -> openModule(new StaffForm(currentUser))),
    menuButton("Manage Events", new Color(156, 39, 176), () -> openModule(new EventForm(currentUser))),
    menuButton("Manage Subscriptions", new Color(0, 172, 193), () -> openModule(new SubscriptionForm(currentUser))),
    menuButton("Student - Club Enrollment", new Color(220, 53, 69), () -> openModule(new EnrollmentForm(currentUser))),
    menuButton("Club Statistics", new Color(63, 81, 181), () -> new ClubStatsForm().setVisible(true))
};

for (int i = 0; i < buttons.length; i++) {
    JButton btn = buttons[i];
    
    btn.setPreferredSize(buttonSize);
    btn.setMaximumSize(buttonSize);
    btn.setMinimumSize(buttonSize);
    
    btn.setAlignmentX(Component.CENTER_ALIGNMENT);
    
    menu.add(btn);
    
    if (i < buttons.length - 1) {
        menu.add(Box.createRigidArea(new Dimension(0, 12)));
    }
}

add(menu, BorderLayout.CENTER);

        JPanel footer = new JPanel(new FlowLayout(FlowLayout.RIGHT, 20, 12));
        footer.setOpaque(false);
        JButton logoutBtn = new JButton("Logout");
        UIStyle.styleButton(logoutBtn, new Color(220, 53, 69));
        logoutBtn.addActionListener(e -> logout());
        footer.add(logoutBtn);
        add(footer, BorderLayout.SOUTH);
    }


    private void openModule(JFrame form) {
        setVisible(false);
        form.addWindowListener(new WindowAdapter() {
            @Override
            public void windowClosed(WindowEvent e) {
                MainDashboard.this.setVisible(true);
            }
        });
        form.setVisible(true);
    }

    private void logout() {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to logout?",
                "Confirm Logout", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            dispose();
            SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
        }
    }

    private JPanel headerWithSubtitle(String title, String subtitle) {
        JPanel panel = UIStyle.headerPanel(title);
        JLabel subLabel = new JLabel(subtitle);
        subLabel.setForeground(Color.WHITE);
        subLabel.setFont(UIStyle.FONT_LABEL);
        panel.add(subLabel, BorderLayout.EAST);
        return panel;
    }

    private JButton menuButton(String text, Color color, Runnable action) {
        JButton button = new JButton(text);
        UIStyle.styleButton(button, color);
        button.setFont(UIStyle.FONT_TITLE.deriveFont(15f));
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));
        button.addActionListener(e -> action.run());
        return button;
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        CurrentUser testAdmin = new CurrentUser(1, "Test Admin", "ADMIN", 1);
        SwingUtilities.invokeLater(() -> new MainDashboard(testAdmin).setVisible(true));
    }
}