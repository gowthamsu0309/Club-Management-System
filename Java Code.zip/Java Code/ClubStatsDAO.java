//import clubmanage.*;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ClubStatsDAO {

    /** Each row: [clubId, clubName, place, totalStudents] */
    public List<Object[]> getClubMemberCounts() throws SQLException {
        List<Object[]> results = new ArrayList<>();
        String call = "{CALL GetClubMemberCounts()}";

        try (Connection con = DBConnection.getConnection();
             CallableStatement stmt = con.prepareCall(call);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                results.add(new Object[]{
                        rs.getInt("club_id"),
                        rs.getString("club_name"),
                        rs.getString("place"),
                        rs.getInt("total_students")
                });
            }
        }
        return results;
    }
}
