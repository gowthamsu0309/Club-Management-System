
public class Student {
    private String admissionNo;
    private String name;
    private String department;
    private String role;
    private Integer subscriptionId; // nullable
    private String email; // nullable

    public Student() {}

    public Student(String admissionNo, String name, String department, String role, Integer subscriptionId) {
        this.admissionNo = admissionNo;
        this.name = name;
        this.department = department;
        this.role = role;
        this.subscriptionId = subscriptionId;
    }

    public Student(String admissionNo, String name, String department, String role, Integer subscriptionId, String email) {
        this(admissionNo, name, department, role, subscriptionId);
        this.email = email;
    }

    public String getAdmissionNo() { return admissionNo; }
    public void setAdmissionNo(String admissionNo) { this.admissionNo = admissionNo; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDepartment() { return department; }
    public void setDepartment(String department) { this.department = department; }

    public String getRole() { return role; }
    public void setRole(String role) { this.role = role; }

    public Integer getSubscriptionId() { return subscriptionId; }
    public void setSubscriptionId(Integer subscriptionId) { this.subscriptionId = subscriptionId; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}