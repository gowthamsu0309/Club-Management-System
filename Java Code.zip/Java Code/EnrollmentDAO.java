import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class EnrollmentDAO {

    public void enroll(String admissionNo, int clubId) throws SQLException {
        String sql = "INSERT INTO stud_club (admission_no, club_id) VALUES (?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, admissionNo);
            ps.setInt(2, clubId);
            ps.executeUpdate();
        }
    }

    public void unenroll(String admissionNo, int clubId) throws SQLException {
        String sql = "DELETE FROM stud_club WHERE admission_no = ? AND club_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, admissionNo);
            ps.setInt(2, clubId);
            ps.executeUpdate();
        }
    }

    /** Used for permission checks: is this student enrolled in this club? */
    public boolean isStudentInClub(String admissionNo, int clubId) throws SQLException {
        String sql = "SELECT 1 FROM stud_club WHERE admission_no = ? AND club_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, admissionNo);
            ps.setInt(2, clubId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }
        }
    }

    /** Returns full Student records (including email) for every student enrolled in the given club. */
    public List<Student> getStudentsInClub(int clubId) throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT s.admission_no, s.name, s.department, s.role, s.subscription_id, s.email " +
                "FROM stud_club sc JOIN student s ON sc.admission_no = s.admission_no " +
                "WHERE sc.club_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, clubId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    String admissionNo = rs.getString(1);
                    String name = rs.getString(2);
                    String department = rs.getString(3);
                    String role = rs.getString(4);
                    int subId = rs.getInt(5);
                    Integer subscriptionId = rs.wasNull() ? null : subId;
                    String email = rs.getString(6);
                    list.add(new Student(admissionNo, name, department, role, subscriptionId, email));
                }
            }
        }
        return list;
    }

    /** Returns rows of [admissionNo, studentName, clubId, clubName] via a join. */
    public List<String[]> getAllEnrollments() throws SQLException {
        List<String[]> list = new ArrayList<>();
        String sql = "SELECT s.admission_no, s.name, c.club_id, c.name " +
                "FROM stud_club sc " +
                "JOIN student s ON sc.admission_no = s.admission_no " +
                "JOIN club c ON sc.club_id = c.club_id " +
                "ORDER BY s.name";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new String[]{
                        rs.getString(1), rs.getString(2), rs.getString(3), rs.getString(4)
                });
            }
        }
        return list;
    }
}