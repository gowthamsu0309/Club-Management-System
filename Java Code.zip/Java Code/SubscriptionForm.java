import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;


public class SubscriptionForm extends JFrame {

    private final SubscriptionDAO subscriptionDAO = new SubscriptionDAO();
    private final CurrentUser currentUser;

    private JTextField idField, amountField, startDateField, endDateField;
    private JTable table;
    private DefaultTableModel tableModel;

    public SubscriptionForm(CurrentUser currentUser) {
        this.currentUser = currentUser;

        setTitle("Subscription Management");
        setSize(700, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(224, 247, 250), new Color(198, 239, 244)));

        add(UIStyle.headerPanel("Subscription Management"), BorderLayout.NORTH);

        if (!currentUser.isAdmin()) {
            JPanel deniedPanel = UIStyle.contentPanel(new BorderLayout());
            JLabel denied = new JLabel("Subscription data is restricted to Admin only.", SwingConstants.CENTER);
            denied.setFont(UIStyle.FONT_TITLE.deriveFont(14f));
            deniedPanel.add(denied, BorderLayout.CENTER);
            add(deniedPanel, BorderLayout.CENTER);
            add(buildBackPanel(), BorderLayout.SOUTH);
            return;
        }

        JPanel center = UIStyle.contentPanel(new BorderLayout(10, 10));
        center.add(buildFormPanel(), BorderLayout.NORTH);
        center.add(buildTablePanel(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);
        

        add(buildBackPanel(), BorderLayout.SOUTH);

        loadIntoTable();
    }

    private JPanel buildBackPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        footer.setOpaque(false);
        JButton backBtn = new JButton("Back");
        UIStyle.styleButton(backBtn, new Color(108, 117, 125));
        backBtn.addActionListener(e -> dispose());
        footer.add(backBtn);
        return footer;
    }

    private JPanel buildFormPanel() {
        JPanel fields = new JPanel(new GridLayout(2, 3, 10, 10));
        fields.setBackground(UIStyle.BG);

        idField = new JTextField();
        idField.setEditable(false);
        amountField = new JTextField();
        startDateField = new JTextField();
        endDateField = new JTextField();
        UIStyle.styleTextField(idField);
        UIStyle.styleTextField(amountField);
        UIStyle.styleTextField(startDateField);
        UIStyle.styleTextField(endDateField);

        fields.add(labeled("Subscription ID (auto)", idField));
        fields.add(labeled("Amount", amountField));
        fields.add(labeled("Start Date (yyyy-MM-dd)", startDateField));
        fields.add(labeled("End Date (yyyy-MM-dd)", endDateField));
        fields.add(new JLabel());
        fields.add(new JLabel());

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        UIStyle.styleButton(addBtn, new Color(46, 160, 67));
        UIStyle.styleButton(updateBtn, UIStyle.PRIMARY);
        UIStyle.styleButton(deleteBtn, new Color(220, 53, 69));
        UIStyle.styleButton(clearBtn, new Color(108, 117, 125));

        addBtn.addActionListener(e -> addSubscription());
        updateBtn.addActionListener(e -> updateSubscription());
        deleteBtn.addActionListener(e -> deleteSubscription());
        clearBtn.addActionListener(e -> clearFields());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(UIStyle.BG);
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UIStyle.BG);
        wrapper.add(fields, BorderLayout.CENTER);
        wrapper.add(buttonPanel, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel labeled(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(UIStyle.BG);
        JLabel label = new JLabel(labelText);
        UIStyle.styleLabel(label);
        p.add(label, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private JScrollPane buildTablePanel() {
        tableModel = UIStyle.nonEditableModel(new Object[]{"ID", "Amount", "Start Date", "End Date"});
        table = new JTable(tableModel);
        UIStyle.styleTable(table);
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 228, 232)));
        return scroll;
    }

    private void loadIntoTable() {
        try {
            tableModel.setRowCount(0);
            List<Subscription> list = subscriptionDAO.getAllSubscriptions();
            for (Subscription s : list) {
                tableModel.addRow(new Object[]{s.getSubscriptionId(), s.getAmount(), s.getStartDate(), s.getEndDate()});
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idField.setText(tableModel.getValueAt(row, 0).toString());
            amountField.setText(tableModel.getValueAt(row, 1).toString());
            startDateField.setText(tableModel.getValueAt(row, 2).toString());
            endDateField.setText(tableModel.getValueAt(row, 3).toString());
        }
    }

    private void addSubscription() {
        try {
            Subscription s = new Subscription(0, Double.parseDouble(amountField.getText()),
                    startDateField.getText(), endDateField.getText());
            subscriptionDAO.addSubscription(s);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Subscription added successfully.");
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Amount must be a number.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void updateSubscription() {
        try {
            if (idField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Select a row from the table first.");
                return;
            }
            Subscription s = new Subscription(Integer.parseInt(idField.getText()),
                    Double.parseDouble(amountField.getText()), startDateField.getText(), endDateField.getText());
            subscriptionDAO.updateSubscription(s);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Subscription updated successfully.");
        } catch (NumberFormatException nfe) {
            JOptionPane.showMessageDialog(this, "Amount must be a number.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void deleteSubscription() {
        try {
            if (idField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Select a row from the table first.");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Delete this subscription?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            subscriptionDAO.deleteSubscription(Integer.parseInt(idField.getText()));
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Subscription deleted successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void clearFields() {
        idField.setText("");
        amountField.setText("");
        startDateField.setText("");
        endDateField.setText("");
        table.clearSelection();
    }

    private void showError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        CurrentUser testAdmin = new CurrentUser(1, "Test Admin", "ADMIN", 1);
        SwingUtilities.invokeLater(() -> new SubscriptionForm(testAdmin).setVisible(true));
    }
}