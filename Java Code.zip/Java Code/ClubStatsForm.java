import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;


public class ClubStatsForm extends JFrame {

    private final ClubStatsDAO clubStatsDAO = new ClubStatsDAO();

    private JTable table;
    private DefaultTableModel tableModel;

    public ClubStatsForm() {
        setTitle("Club Statistics");
        setSize(650, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(232, 234, 246), new Color(197, 202, 233)));

        add(UIStyle.headerPanel("Club Statistics"), BorderLayout.NORTH);

        JPanel center = UIStyle.contentPanel(new BorderLayout(10, 10));
        center.add(buildTablePanel(), BorderLayout.CENTER);
        center.add(buildButtonPanel(), BorderLayout.PAGE_START);
        center.add(buildBackPanel(), BorderLayout.SOUTH);
        add(center, BorderLayout.CENTER);

        loadStats();
    }
    

    private JScrollPane buildTablePanel() {
        tableModel = UIStyle.nonEditableModel(new Object[]{"Club ID", "Club Name", "Place", "Total Students"});
        table = new JTable(tableModel);
        UIStyle.styleTable(table);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 228, 232)));
        return scroll;
    }
    private JPanel buildBackPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        footer.setOpaque(false);
        JButton backBtn = new JButton("Back");
        UIStyle.styleButton(backBtn, new Color(108, 117, 125));
        backBtn.addActionListener(e -> dispose());
        footer.add(backBtn);
        return footer;
    }

    private JPanel buildButtonPanel() {
        JButton refreshBtn = new JButton("Refresh");
        UIStyle.styleButton(refreshBtn, UIStyle.PRIMARY);
        refreshBtn.addActionListener(e -> loadStats());
        

        JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        panel.setOpaque(false);
        panel.add(refreshBtn);
        return panel;
    }
    
    

    private void loadStats() {
        try {
            tableModel.setRowCount(0);
            List<Object[]> rows = clubStatsDAO.getClubMemberCounts();
            for (Object[] row : rows) {
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this,
                    "Database error: " + e.getMessage() +
                            "\n\nMake sure you ran procedures.sql in MySQL Workbench first.",
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        SwingUtilities.invokeLater(() -> new ClubStatsForm().setVisible(true));
    }
}