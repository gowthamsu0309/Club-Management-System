import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class StaffForm extends JFrame {

    private final StaffDAO staffDAO = new StaffDAO();
    private final ClubDAO clubDAO = new ClubDAO();
    private final CurrentUser currentUser;

    private JTextField idField, nameField, designationField;
    private JComboBox<String> clubCombo;
    private JTable table;
    private DefaultTableModel tableModel;

    public StaffForm(CurrentUser currentUser) {
        this.currentUser = currentUser;

        setTitle("Staff Management");
        setSize(700, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(255, 243, 224), new Color(255, 224, 178)));

        add(UIStyle.headerPanel("Staff Management"), BorderLayout.NORTH);

        JPanel center = UIStyle.contentPanel(new BorderLayout(10, 10));
        center.add(buildFormPanel(), BorderLayout.NORTH);
        center.add(buildTablePanel(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        add(buildBackPanel(), BorderLayout.SOUTH);

        loadClubOptions();
        loadIntoTable();
    }

    private JPanel buildBackPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        footer.setOpaque(false);
        JButton backBtn = new JButton("Back");
        UIStyle.styleButton(backBtn, new Color(108, 117, 125));
        backBtn.addActionListener(e -> dispose());
        footer.add(backBtn);
        return footer;
    }

    private JPanel buildFormPanel() {
        JPanel fields = new JPanel(new GridLayout(2, 3, 10, 10));
        fields.setBackground(UIStyle.BG);

        idField = new JTextField();
        idField.setEditable(false);
        nameField = new JTextField();
        designationField = new JTextField();
        clubCombo = new JComboBox<>();
        UIStyle.styleTextField(idField);
        UIStyle.styleTextField(nameField);
        UIStyle.styleTextField(designationField);
        UIStyle.styleComboBox(clubCombo);

        fields.add(labeled("Staff ID (auto)", idField));
        fields.add(labeled("Name", nameField));
        fields.add(labeled("Designation", designationField));
        fields.add(labeled("Club (Incharge of)", clubCombo));
        fields.add(new JLabel());
        fields.add(new JLabel());

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        UIStyle.styleButton(addBtn, new Color(46, 160, 67));
        UIStyle.styleButton(updateBtn, UIStyle.PRIMARY);
        UIStyle.styleButton(deleteBtn, new Color(220, 53, 69));
        UIStyle.styleButton(clearBtn, new Color(108, 117, 125));

        // Staff role: view only - disable all modification buttons entirely
        boolean canManage = currentUser.isAdmin();
        addBtn.setEnabled(canManage);
        updateBtn.setEnabled(canManage);
        deleteBtn.setEnabled(canManage);
        if (!canManage) {
            setTitle(getTitle() + " (View Only)");
        }

        addBtn.addActionListener(e -> addStaff());
        updateBtn.addActionListener(e -> updateStaff());
        deleteBtn.addActionListener(e -> deleteStaff());
        clearBtn.addActionListener(e -> clearFields());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(UIStyle.BG);
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UIStyle.BG);
        wrapper.add(fields, BorderLayout.CENTER);
        wrapper.add(buttonPanel, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel labeled(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(UIStyle.BG);
        JLabel label = new JLabel(labelText);
        UIStyle.styleLabel(label);
        p.add(label, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private JScrollPane buildTablePanel() {
        tableModel = UIStyle.nonEditableModel(new Object[]{"Staff ID", "Name", "Designation", "Club ID"});
        table = new JTable(tableModel);
        UIStyle.styleTable(table);
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 228, 232)));
        return scroll;
    }

    private void loadClubOptions() {
        try {
            clubCombo.removeAllItems();
            clubCombo.addItem("None");
            List<Club> clubs = clubDAO.getAllClubs();
            for (Club c : clubs) {
                clubCombo.addItem(c.getClubId() + " - " + c.getName());
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private Integer selectedClubId() {
        String selected = (String) clubCombo.getSelectedItem();
        if (selected == null || selected.equals("None")) return null;
        return Integer.parseInt(selected.split(" - ")[0]);
    }

    private void selectClubById(Object idObj) {
        if (idObj == null) {
            clubCombo.setSelectedItem("None");
            return;
        }
        String idStr = idObj.toString();
        for (int i = 0; i < clubCombo.getItemCount(); i++) {
            String item = clubCombo.getItemAt(i);
            if (item.startsWith(idStr + " - ")) {
                clubCombo.setSelectedIndex(i);
                return;
            }
        }
        clubCombo.setSelectedItem("None");
    }

    private void loadIntoTable() {
        try {
            tableModel.setRowCount(0);
            List<Staff> list = staffDAO.getAllStaff(); // view ALL staff regardless of role
            for (Staff s : list) {
                tableModel.addRow(new Object[]{s.getStaffId(), s.getName(), s.getDesignation(), s.getClubId()});
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idField.setText(tableModel.getValueAt(row, 0).toString());
            nameField.setText(tableModel.getValueAt(row, 1).toString());
            designationField.setText(tableModel.getValueAt(row, 2).toString());
            selectClubById(tableModel.getValueAt(row, 3));
        }
    }

    private void addStaff() {
        try {
            if (nameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name is required.");
                return;
            }
            Staff s = new Staff(0, nameField.getText(), designationField.getText(), selectedClubId());
            staffDAO.addStaff(s);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Staff added successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void updateStaff() {
        try {
            if (idField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Select a staff member from the table first.");
                return;
            }
            Staff s = new Staff(Integer.parseInt(idField.getText()), nameField.getText(),
                    designationField.getText(), selectedClubId());
            staffDAO.updateStaff(s);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Staff updated successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void deleteStaff() {
        try {
            if (idField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Select a staff member from the table first.");
                return;
            }
            int confirm = JOptionPane.showConfirmDialog(this, "Delete this staff member?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            staffDAO.deleteStaff(Integer.parseInt(idField.getText()));
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Staff deleted successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        designationField.setText("");
        clubCombo.setSelectedItem("None");
        table.clearSelection();
    }

    private void showError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        CurrentUser testAdmin = new CurrentUser(1, "Test Admin", "ADMIN", 1);
        SwingUtilities.invokeLater(() -> new StaffForm(testAdmin).setVisible(true));
    }
}