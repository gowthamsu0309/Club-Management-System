

public class Subscription {
    private int subscriptionId;
    private double amount;
    private String startDate; // stored/displayed as yyyy-MM-dd
    private String endDate;

    public Subscription() {}

    public Subscription(int subscriptionId, double amount, String startDate, String endDate) {
        this.subscriptionId = subscriptionId;
        this.amount = amount;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public int getSubscriptionId() { return subscriptionId; }
    public void setSubscriptionId(int subscriptionId) { this.subscriptionId = subscriptionId; }

    public double getAmount() { return amount; }
    public void setAmount(double amount) { this.amount = amount; }

    public String getStartDate() { return startDate; }
    public void setStartDate(String startDate) { this.startDate = startDate; }

    public String getEndDate() { return endDate; }
    public void setEndDate(String endDate) { this.endDate = endDate; }
}
