

public class CurrentUser {
    private final int staffId;
    private final String name;
    private final String role;      // "ADMIN" or "STAFF"
    private final Integer clubId;   // the club this staff belongs to (null possible for admin)

    public CurrentUser(int staffId, String name, String role, Integer clubId) {
        this.staffId = staffId;
        this.name = name;
        this.role = role;
        this.clubId = clubId;
    }

    public int getStaffId() { return staffId; }
    public String getName() { return name; }
    public String getRole() { return role; }
    public Integer getClubId() { return clubId; }

    public boolean isAdmin() { return "ADMIN".equalsIgnoreCase(role); }

    /** Admin owns everything; Staff only owns records matching their own club_id. */
    public boolean owns(Integer recordClubId) {
        if (isAdmin()) return true;
        return clubId != null && clubId.equals(recordClubId);
    }
}
