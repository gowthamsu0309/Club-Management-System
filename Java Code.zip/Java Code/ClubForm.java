import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;


public class ClubForm extends JFrame {

    private final ClubDAO clubDAO = new ClubDAO();
    private final CurrentUser currentUser;

    private JTextField idField, nameField, placeField;
    private JTable table;
    private DefaultTableModel tableModel;

    public ClubForm(CurrentUser currentUser) {
        this.currentUser = currentUser;

        setTitle("Club Management");
        setSize(650, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(225, 235, 255), new Color(196, 214, 255)));

        add(UIStyle.headerPanel("Club Management"), BorderLayout.NORTH);
        
        JPanel page = UIStyle.imageBackgroundFromMain("main.jpg");        
        setContentPane(page);
        
        GridBagConstraints outer = new GridBagConstraints();
        outer.gridx = 0;
        outer.gridy = 0;

        JPanel center = UIStyle.contentPanel(new BorderLayout(10, 10));
        center.add(buildFormPanel(), BorderLayout.NORTH);
        center.add(buildTablePanel(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        add(buildBackPanel(), BorderLayout.SOUTH);

        loadClubsIntoTable();
    }

    private JPanel buildBackPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        footer.setOpaque(false);
        JButton backBtn = new JButton("Back");
        UIStyle.styleButton(backBtn, new Color(108, 117, 125));
        backBtn.addActionListener(e -> dispose());
        footer.add(backBtn);
        return footer;
    }

    private JPanel buildFormPanel() {
        JPanel fields = new JPanel(new GridLayout(2, 2, 10, 10));
        fields.setBackground(UIStyle.BG);

        idField = new JTextField();
        idField.setEditable(false);
        nameField = new JTextField();
        placeField = new JTextField();
        UIStyle.styleTextField(idField);
        UIStyle.styleTextField(nameField);
        UIStyle.styleTextField(placeField);

        fields.add(labeled("Club ID (auto)", idField));
        fields.add(labeled("Name", nameField));
        fields.add(labeled("Place", placeField));
        fields.add(new JLabel());

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        UIStyle.styleButton(addBtn, new Color(46, 160, 67));
        UIStyle.styleButton(updateBtn, UIStyle.PRIMARY);
        UIStyle.styleButton(deleteBtn, new Color(220, 53, 69));
        UIStyle.styleButton(clearBtn, new Color(108, 117, 125));

        // Only Admin can create a brand new club (a new club has no "owner" yet)
        addBtn.setEnabled(currentUser.isAdmin());

        addBtn.addActionListener(e -> addClub());
        updateBtn.addActionListener(e -> updateClub());
        deleteBtn.addActionListener(e -> deleteClub());
        clearBtn.addActionListener(e -> clearFields());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(UIStyle.BG);
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UIStyle.BG);
        wrapper.add(fields, BorderLayout.CENTER);
        wrapper.add(buttonPanel, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel labeled(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(UIStyle.BG);
        JLabel label = new JLabel(labelText);
        UIStyle.styleLabel(label);
        p.add(label, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private JScrollPane buildTablePanel() {
        tableModel = UIStyle.nonEditableModel(new Object[]{"Club ID", "Name", "Place"});
        table = new JTable(tableModel);
        UIStyle.styleTable(table);
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 228, 232)));
        return scroll;
    }

    private void loadClubsIntoTable() {
        try {
            tableModel.setRowCount(0);
            List<Club> clubs = clubDAO.getAllClubs(); // view ALL clubs regardless of role
            for (Club c : clubs) {
                tableModel.addRow(new Object[]{c.getClubId(), c.getName(), c.getPlace()});
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idField.setText(tableModel.getValueAt(row, 0).toString());
            nameField.setText(tableModel.getValueAt(row, 1).toString());
            placeField.setText(tableModel.getValueAt(row, 2).toString());
        }
    }

    private boolean canModifySelected() {
        if (idField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a club from the table first.");
            return false;
        }
        int selectedClubId = Integer.parseInt(idField.getText());
        if (!currentUser.owns(selectedClubId)) {
            JOptionPane.showMessageDialog(this,
                    "You can only modify your own club. This one belongs to a different club.",
                    "Not allowed", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    private void addClub() {
        try {
            if (nameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name is required.");
                return;
            }
            Club club = new Club(0, nameField.getText(), placeField.getText());
            clubDAO.addClub(club);
            loadClubsIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Club added successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void updateClub() {
        try {
            if (!canModifySelected()) return;
            Club club = new Club(Integer.parseInt(idField.getText()), nameField.getText(), placeField.getText());
            clubDAO.updateClub(club);
            loadClubsIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Club updated successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void deleteClub() {
        try {
            if (!canModifySelected()) return;
            int confirm = JOptionPane.showConfirmDialog(this, "Delete this club?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            clubDAO.deleteClub(Integer.parseInt(idField.getText()));
            loadClubsIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Club deleted successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        placeField.setText("");
        table.clearSelection();
    }

    private void showError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(),
                "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        CurrentUser testAdmin = new CurrentUser(1, "Test Admin", "ADMIN", 1);
        SwingUtilities.invokeLater(() -> new ClubForm(testAdmin).setVisible(true));
    }
}