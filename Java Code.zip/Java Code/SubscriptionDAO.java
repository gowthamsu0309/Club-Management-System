
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SubscriptionDAO {

    public void addSubscription(Subscription s) throws SQLException {
        String sql = "INSERT INTO subscription (amount, start_date, end_date) VALUES (?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, s.getAmount());
            ps.setString(2, s.getStartDate());
            ps.setString(3, s.getEndDate());
            ps.executeUpdate();
        }
    }

    public void updateSubscription(Subscription s) throws SQLException {
        String sql = "UPDATE subscription SET amount = ?, start_date = ?, end_date = ? WHERE subscription_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setDouble(1, s.getAmount());
            ps.setString(2, s.getStartDate());
            ps.setString(3, s.getEndDate());
            ps.setInt(4, s.getSubscriptionId());
            ps.executeUpdate();
        }
    }

    public void deleteSubscription(int id) throws SQLException {
        String sql = "DELETE FROM subscription WHERE subscription_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    public List<Subscription> getAllSubscriptions() throws SQLException {
        List<Subscription> list = new ArrayList<>();
        String sql = "SELECT subscription_id, amount, start_date, end_date FROM subscription";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(new Subscription(
                        rs.getInt("subscription_id"),
                        rs.getDouble("amount"),
                        rs.getString("start_date"),
                        rs.getString("end_date")
                ));
            }
        }
        return list;
    }
}
