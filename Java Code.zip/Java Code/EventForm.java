import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;


public class EventForm extends JFrame {

    private final EventDAO eventDAO = new EventDAO();
    private final ClubDAO clubDAO = new ClubDAO();
    private final StaffDAO staffDAO = new StaffDAO();
    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private final CurrentUser currentUser;

    private JTextField idField, nameField, dateField;
    private JComboBox<String> clubCombo;
    private JTable table;
    private DefaultTableModel tableModel;

    public EventForm(CurrentUser currentUser) {
        this.currentUser = currentUser;

        setTitle("Event Management");
        setSize(700, 480);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(243, 229, 245), new Color(230, 200, 235)));

        add(UIStyle.headerPanel("Event Management"), BorderLayout.NORTH);

        JPanel center = UIStyle.contentPanel(new BorderLayout(10, 10));
        center.add(buildFormPanel(), BorderLayout.NORTH);
        center.add(buildTablePanel(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        add(buildBackPanel(), BorderLayout.SOUTH);

        loadClubOptions();
        loadIntoTable();
    }

    private JPanel buildBackPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        footer.setOpaque(false);
        JButton backBtn = new JButton("Back");
        UIStyle.styleButton(backBtn, new Color(108, 117, 125));
        backBtn.addActionListener(e -> dispose());
        footer.add(backBtn);
        return footer;
    }

    private JPanel buildFormPanel() {
        JPanel fields = new JPanel(new GridLayout(2, 3, 10, 10));
        fields.setBackground(UIStyle.BG);

        idField = new JTextField();
        idField.setEditable(false);
        nameField = new JTextField();
        dateField = new JTextField();
        clubCombo = new JComboBox<>();
        UIStyle.styleTextField(idField);
        UIStyle.styleTextField(nameField);
        UIStyle.styleTextField(dateField);
        UIStyle.styleComboBox(clubCombo);

        // Staff can only ever create events for their own club - lock the dropdown
        clubCombo.setEnabled(currentUser.isAdmin());

        fields.add(labeled("Event ID (auto)", idField));
        fields.add(labeled("Name", nameField));
        fields.add(labeled("Date (yyyy-MM-dd)", dateField));
        fields.add(labeled("Club", clubCombo));
        fields.add(new JLabel());
        fields.add(new JLabel());

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        JButton mailBtn = new JButton("Mail");
        UIStyle.styleButton(addBtn, new Color(46, 160, 67));
        UIStyle.styleButton(updateBtn, UIStyle.PRIMARY);
        UIStyle.styleButton(deleteBtn, new Color(220, 53, 69));
        UIStyle.styleButton(clearBtn, new Color(108, 117, 125));
        UIStyle.styleButton(mailBtn, new Color(0, 150, 136));

        addBtn.addActionListener(e -> addEvent());
        updateBtn.addActionListener(e -> updateEvent());
        deleteBtn.addActionListener(e -> deleteEvent());
        clearBtn.addActionListener(e -> clearFields());
        mailBtn.addActionListener(e -> mailEvent());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(UIStyle.BG);
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);
        buttonPanel.add(mailBtn);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UIStyle.BG);
        wrapper.add(fields, BorderLayout.CENTER);
        wrapper.add(buttonPanel, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel labeled(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(UIStyle.BG);
        JLabel label = new JLabel(labelText);
        UIStyle.styleLabel(label);
        p.add(label, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private JScrollPane buildTablePanel() {
        tableModel = UIStyle.nonEditableModel(new Object[]{"Event ID", "Name", "Date", "Club ID"});
        table = new JTable(tableModel);
        UIStyle.styleTable(table);
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 228, 232)));
        return scroll;
    }

    private void loadClubOptions() {
        try {
            clubCombo.removeAllItems();
            if (currentUser.isAdmin()) {
                clubCombo.addItem("None");
                List<Club> clubs = clubDAO.getAllClubs();
                for (Club c : clubs) {
                    clubCombo.addItem(c.getClubId() + " - " + c.getName());
                }
            } else {
                // Staff: only their own club is selectable
                List<Club> clubs = clubDAO.getAllClubs();
                for (Club c : clubs) {
                    if (currentUser.getClubId() != null && currentUser.getClubId() == c.getClubId()) {
                        clubCombo.addItem(c.getClubId() + " - " + c.getName());
                    }
                }
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private Integer selectedClubId() {
        String selected = (String) clubCombo.getSelectedItem();
        if (selected == null || selected.equals("None")) return null;
        return Integer.parseInt(selected.split(" - ")[0]);
    }

    private void selectClubById(Object idObj) {
        if (idObj == null) {
            if (clubCombo.getItemCount() > 0 && currentUser.isAdmin()) clubCombo.setSelectedItem("None");
            return;
        }
        String idStr = idObj.toString();
        for (int i = 0; i < clubCombo.getItemCount(); i++) {
            String item = clubCombo.getItemAt(i);
            if (item.startsWith(idStr + " - ")) {
                clubCombo.setSelectedIndex(i);
                return;
            }
        }
    }

    private void loadIntoTable() {
        try {
            tableModel.setRowCount(0);
            List<Event> list = eventDAO.getAllEvents(); // view ALL events regardless of role
            for (Event ev : list) {
                tableModel.addRow(new Object[]{ev.getEventId(), ev.getName(), ev.getEventDate(), ev.getClubId()});
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            idField.setText(tableModel.getValueAt(row, 0).toString());
            nameField.setText(tableModel.getValueAt(row, 1).toString());
            dateField.setText(tableModel.getValueAt(row, 2).toString());
            if (currentUser.isAdmin()) {
                selectClubById(tableModel.getValueAt(row, 3));
            }
        }
    }

    /** Staff can only modify events belonging to their own club. */
    private boolean canModifySelected() {
        if (idField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select an event from the table first.");
            return false;
        }
        if (currentUser.isAdmin()) return true;

        int row = table.getSelectedRow();
        Object clubIdObj = row >= 0 ? tableModel.getValueAt(row, 3) : null;
        Integer eventClubId = clubIdObj != null ? Integer.parseInt(clubIdObj.toString()) : null;

        if (!currentUser.owns(eventClubId)) {
            JOptionPane.showMessageDialog(this,
                    "You can only modify events belonging to your own club.",
                    "Not allowed", JOptionPane.WARNING_MESSAGE);
            return false;
        }
        return true;
    }

    /** Generates an event-notice PDF and emails it to every student enrolled in the event's club. */
    private void mailEvent() {
        if (!canModifySelected()) return;

        int row = table.getSelectedRow();
        String eventName = tableModel.getValueAt(row, 1).toString();
        String eventDate = tableModel.getValueAt(row, 2).toString();
        Object clubIdObj = tableModel.getValueAt(row, 3);
        if (clubIdObj == null) {
            JOptionPane.showMessageDialog(this, "This event has no club assigned - cannot determine recipients.");
            return;
        }
        int clubId = Integer.parseInt(clubIdObj.toString());

        try {
            String clubName = "Unknown Club";
            for (Club c : clubDAO.getAllClubs()) {
                if (c.getClubId() == clubId) {
                    clubName = c.getName();
                    break;
                }
            }

            String inchargeName = "Not Assigned";
            List<Staff> clubStaff = new java.util.ArrayList<>();
            for (Staff s : staffDAO.getAllStaff()) {
                if (s.getClubId() != null && s.getClubId() == clubId) {
                    clubStaff.add(s);
                }
            }
            for (Staff s : clubStaff) {
                if (s.getDesignation() != null && s.getDesignation().toLowerCase().contains("incharge")) {
                    inchargeName = s.getName();
                    break;
                }
            }
            if (inchargeName.equals("Not Assigned") && !clubStaff.isEmpty()) {
                inchargeName = clubStaff.get(0).getName();
            }

            List<Student> members = enrollmentDAO.getStudentsInClub(clubId);
            if (members.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No students are enrolled in this club yet.");
                return;
            }

            java.io.File pdf = PdfService.generateEventNotice(clubName, inchargeName, eventName, eventDate);

            int sent = 0, skipped = 0, failed = 0;
            for (Student s : members) {
                String email = s.getEmail() == null ? "" : s.getEmail().trim();
                if (email.isEmpty()) {
                    skipped++;
                    continue;
                }
                if (!email.matches("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$")) {
                    skipped++;
                    logErrorToFile(new Exception("Skipped invalid email for student "
                            + s.getAdmissionNo() + " (" + s.getName() + "): [" + email + "]"));
                    continue;
                }
                try {
                    MailService.sendEventMail(
                            email,
                            "Event Notice: " + eventName,
                            "Dear " + s.getName() + ",\n\nPlease find attached the notice for the upcoming event \""
                                    + eventName + "\" organized by " + clubName + ".\n\nRegards,\n" + clubName,
                            pdf
                    );
                    sent++;
                } catch (Exception me) {
                    failed++;
                    logErrorToFile(new Exception("Failed sending to " + email + " (student "
                            + s.getAdmissionNo() + ")", me));
                }
            }

            String summary = "Mail complete.\nSent: " + sent + "\nSkipped (no email): " + skipped
                    + "\nFailed: " + failed;
            if (failed > 0) {
                summary += "\n\nSee mail_error_log.txt for failure details.";
            }
            JOptionPane.showMessageDialog(this, summary);

        } catch (SQLException e) {
            showError(e);
        } catch (Exception e) {
            logErrorToFile(e);
            JOptionPane.showMessageDialog(this,
                    "Failed to generate/send PDF: " + e + "\n\nFull details written to mail_error_log.txt",
                    "Mail Error", JOptionPane.ERROR_MESSAGE);
        }
    }


    private void logErrorToFile(Exception e) {
        try (java.io.PrintWriter pw = new java.io.PrintWriter(new java.io.FileWriter("mail_error_log.txt", true))) {
            pw.println("=== " + new java.util.Date() + " ===");
            e.printStackTrace(pw);
            pw.println();
        } catch (Exception logFailure) {
            e.printStackTrace();
        }
    }

    private void addEvent() {
        try {
            if (nameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Name is required.");
                return;
            }
            Event ev = new Event(0, nameField.getText(), dateField.getText(), selectedClubId());
            eventDAO.addEvent(ev);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Event added successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void updateEvent() {
        try {
            if (!canModifySelected()) return;
            Event ev = new Event(Integer.parseInt(idField.getText()), nameField.getText(),
                    dateField.getText(), selectedClubId());
            eventDAO.updateEvent(ev);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Event updated successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void deleteEvent() {
        try {
            if (!canModifySelected()) return;
            int confirm = JOptionPane.showConfirmDialog(this, "Delete this event?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            eventDAO.deleteEvent(Integer.parseInt(idField.getText()));
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Event deleted successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        dateField.setText("");
        if (clubCombo.getItemCount() > 0) clubCombo.setSelectedIndex(0);
        table.clearSelection();
    }

    private void showError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        CurrentUser testAdmin = new CurrentUser(1, "Test Admin", "ADMIN", 1);
        SwingUtilities.invokeLater(() -> new EventForm(testAdmin).setVisible(true));
    }
}