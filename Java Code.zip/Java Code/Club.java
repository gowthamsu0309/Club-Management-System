public class Club {
    private int clubId;
    private String name;
    private String place;

    public Club() {}

    public Club(int clubId, String name, String place) {
        this.clubId = clubId;
        this.name = name;
        this.place = place;
    }

    public int getClubId() { return clubId; }
    public void setClubId(int clubId) { this.clubId = clubId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getPlace() { return place; }
    public void setPlace(String place) { this.place = place; }
}
