

public class Staff {
    private int staffId;
    private String name;
    private String designation;
    private Integer clubId; // nullable

    public Staff() {}

    public Staff(int staffId, String name, String designation, Integer clubId) {
        this.staffId = staffId;
        this.name = name;
        this.designation = designation;
        this.clubId = clubId;
    }

    public int getStaffId() { return staffId; }
    public void setStaffId(int staffId) { this.staffId = staffId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDesignation() { return designation; }
    public void setDesignation(String designation) { this.designation = designation; }

    public Integer getClubId() { return clubId; }
    public void setClubId(Integer clubId) { this.clubId = clubId; }
}
