import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;
import java.sql.SQLException;

public class LoginForm extends JFrame {

    private final StaffDAO staffDAO = new StaffDAO();

    private static final Color NAVY = new Color(27, 54, 93);
    private static final Color GOLD = new Color(196, 155, 60);
    private static final Color CARD_BG = new Color(250, 247, 240);
    private static final Color FIELD_BORDER = new Color(214, 205, 186);
    private static final Color MUTED_TEXT = new Color(110, 110, 110);

    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton togglePasswordBtn;
    private boolean passwordVisible = false;

    public LoginForm() {
        setTitle("Club Management System - Login");
        setSize(480, 640);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel page = UIStyle.imageBackgroundFromResource("login_background.jpg");
        page.setLayout(new GridBagLayout());
        setContentPane(page);

        GridBagConstraints outer = new GridBagConstraints();
        outer.gridx = 0;
        outer.gridy = 0;
        page.add(buildCard(), outer);
    }

    private JPanel buildCard() {
        RoundedPanel card = new RoundedPanel(24, CARD_BG);
        card.setLayout(new GridBagLayout());
        card.setPreferredSize(new Dimension(360, 560));
        card.setBorder(BorderFactory.createEmptyBorder(30, 34, 26, 34));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.gridx = 0;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(0, 0, 4, 0);
        int row = 0;

        JLabel title = new JLabel("WELCOME BACK", SwingConstants.CENTER);
        title.setFont(new Font("Segoe UI", Font.BOLD, 22));
        title.setForeground(NAVY);
        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 8, 0);
        card.add(title, gbc);

      /*  JLabel subtitle = new JLabel("", SwingConstants.CENTER);
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        subtitle.setForeground(MUTED_TEXT);
        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 22, 0);
        card.add(subtitle, gbc);*/

        gbc.insets = new Insets(0, 2, 4, 0);
        gbc.gridy = row++;
        card.add(sectionLabel("USERNAME"), gbc);

        usernameField = new JTextField();
        usernameField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        usernameField.setOpaque(false);
        usernameField.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        JPanel usernameWrap = new JPanel(new BorderLayout());
        usernameWrap.setOpaque(false);
        usernameWrap.setBorder(new RoundedBorder(FIELD_BORDER, 10, 10, 10, 10, 10));
        usernameWrap.add(usernameField, BorderLayout.CENTER);
        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 16, 0);
        card.add(usernameWrap, gbc);

        gbc.insets = new Insets(0, 2, 4, 0);
        gbc.gridy = row++;
        card.add(sectionLabel("PASSWORD"), gbc);

        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 12, 0);
        card.add(buildPasswordField(), gbc);

        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 20, 0);
        card.add(buildRememberForgotRow(), gbc);

        JButton loginBtn = new RoundedButton("LOG IN", NAVY, Color.WHITE, 10);
        loginBtn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        loginBtn.setPreferredSize(new Dimension(0, 42));
        loginBtn.addActionListener(e -> attemptLogin());
        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 16, 0);
        card.add(loginBtn, gbc);

        gbc.gridy = row++;
        gbc.insets = new Insets(0, 0, 4, 0);
        card.add(buildSignUpRow(), gbc);

        JButton exitLink = new JButton("Exit application");
        exitLink.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        exitLink.setForeground(MUTED_TEXT);
        exitLink.setBorderPainted(false);
        exitLink.setContentAreaFilled(false);
        exitLink.setCursor(new Cursor(Cursor.HAND_CURSOR));
        exitLink.addActionListener(e -> exitApplication());
        gbc.gridy = row++;
        gbc.insets = new Insets(10, 0, 0, 0);
        card.add(exitLink, gbc);

        // Pressing Enter in the password field also logs in
        passwordField.addActionListener(e -> attemptLogin());

        return card;
    }

    private JLabel sectionLabel(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 10));
        label.setForeground(MUTED_TEXT);
        return label;
    }

    private JPanel buildPasswordField() {
        JPanel wrap = new JPanel(new BorderLayout());
        wrap.setOpaque(false);
        wrap.setBorder(new RoundedBorder(FIELD_BORDER, 10, 10, 10, 4, 10));

        passwordField = new JPasswordField();
        passwordField.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        passwordField.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));
        passwordField.setOpaque(false);

        togglePasswordBtn = new JButton("Show");
        togglePasswordBtn.setFont(new Font("Segoe UI", Font.PLAIN, 11));
        togglePasswordBtn.setForeground(NAVY);
        togglePasswordBtn.setBorderPainted(false);
        togglePasswordBtn.setContentAreaFilled(false);
        togglePasswordBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        togglePasswordBtn.addActionListener(e -> togglePasswordVisibility());

        wrap.add(passwordField, BorderLayout.CENTER);
        wrap.add(togglePasswordBtn, BorderLayout.EAST);
        return wrap;
    }

    private void togglePasswordVisibility() {
        passwordVisible = !passwordVisible;
        passwordField.setEchoChar(passwordVisible ? (char) 0 : '\u2022');
        togglePasswordBtn.setText(passwordVisible ? "Hide" : "Show");
    }

    private JPanel buildRememberForgotRow() {
        JPanel row = new JPanel(new BorderLayout());
        row.setOpaque(false);

        JCheckBox rememberMe = new JCheckBox("Remember me");
        rememberMe.setOpaque(false);
        rememberMe.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        rememberMe.setForeground(MUTED_TEXT);

        JButton forgotBtn = new JButton("Forgot Password?");
        forgotBtn.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        forgotBtn.setForeground(NAVY);
        forgotBtn.setBorderPainted(false);
        forgotBtn.setContentAreaFilled(false);
        forgotBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        forgotBtn.addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Password reset isn't available yet. Please contact an admin.",
                        "Coming Soon", JOptionPane.INFORMATION_MESSAGE));

        row.add(rememberMe, BorderLayout.WEST);
        row.add(forgotBtn, BorderLayout.EAST);
        return row;
    }

    private JPanel buildSignUpRow() {
        JPanel row = new JPanel(new FlowLayout(FlowLayout.CENTER, 4, 0));
        row.setOpaque(false);

        JLabel prompt = new JLabel("Don't have an account?");
        prompt.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        prompt.setForeground(MUTED_TEXT);

        JButton signUpBtn = new JButton("Sign Up");
        signUpBtn.setFont(new Font("Segoe UI", Font.BOLD, 12));
        signUpBtn.setForeground(GOLD);
        signUpBtn.setBorderPainted(false);
        signUpBtn.setContentAreaFilled(false);
        signUpBtn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        signUpBtn.addActionListener(e ->
                JOptionPane.showMessageDialog(this, "Self sign-up isn't available yet. Please contact an admin.",
                        "Coming Soon", JOptionPane.INFORMATION_MESSAGE));

        row.add(prompt);
        row.add(signUpBtn);
        return row;
    }

    private void exitApplication() {
        int choice = JOptionPane.showConfirmDialog(this, "Are you sure you want to exit?",
                "Confirm Exit", JOptionPane.YES_NO_OPTION);
        if (choice == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }

    private void attemptLogin() {
        String username = usernameField.getText().trim();
        String password = new String(passwordField.getPassword());

        if (username.isEmpty() || password.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter both username and password.");
            return;
        }

        try {
            CurrentUser user = staffDAO.login(username, password);
            if (user == null) {
                JOptionPane.showMessageDialog(this, "Invalid username or password.",
                        "Login Failed", JOptionPane.ERROR_MESSAGE);
                return;
            }
            dispose();
            SwingUtilities.invokeLater(() -> new MainDashboard(user).setVisible(true));
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(),
                    "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    /** A JPanel with rounded corners and a solid fill color, used for the login card. */
    private static class RoundedPanel extends JPanel {
        private final int radius;
        private final Color bg;

        RoundedPanel(int radius, Color bg) {
            this.radius = radius;
            this.bg = bg;
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    /** A rounded rectangle border with configurable padding, used on text fields/combo boxes. */
    private static class RoundedBorder extends AbstractBorder {
        private final Color color;
        private final int top, left, bottom, right, radius;

        RoundedBorder(Color color, int top, int left, int bottom, int right, int radius) {
            this.color = color;
            this.top = top;
            this.left = left;
            this.bottom = bottom;
            this.right = right;
            this.radius = radius;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(Color.WHITE);
            g2.fillRoundRect(x, y, width - 1, height - 1, radius, radius);
            g2.setColor(color);
            g2.drawRoundRect(x, y, width - 1, height - 1, radius, radius);
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(top, left, bottom, right);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.top = top;
            insets.left = left;
            insets.bottom = bottom;
            insets.right = right;
            return insets;
        }
    }

    /** A JButton with rounded corners and a solid fill - used for the LOG IN button. */
    private static class RoundedButton extends JButton {
        private final Color bg;
        private final int radius;

        RoundedButton(String text, Color bg, Color fg, int radius) {
            super(text);
            this.bg = bg;
            this.radius = radius;
            setForeground(fg);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setFocusPainted(false);
            setCursor(new Cursor(Cursor.HAND_CURSOR));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(bg);
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), radius, radius);
            g2.dispose();
            super.paintComponent(g);
        }
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        SwingUtilities.invokeLater(() -> new LoginForm().setVisible(true));
    }
}