//import clubmanage.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ClubDAO {

    public void addClub(Club club) throws SQLException {
        String sql = "INSERT INTO club (name, place) VALUES (?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, club.getName());
            ps.setString(2, club.getPlace());
            ps.executeUpdate();
        }
    }

    public void updateClub(Club club) throws SQLException {
        String sql = "UPDATE club SET name = ?, place = ? WHERE club_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, club.getName());
            ps.setString(2, club.getPlace());
            ps.setInt(3, club.getClubId());
            ps.executeUpdate();
        }
    }

    public void deleteClub(int clubId) throws SQLException {
        String sql = "DELETE FROM club WHERE club_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, clubId);
            ps.executeUpdate();
        }
    }

    public List<Club> getAllClubs() throws SQLException {
        List<Club> clubs = new ArrayList<>();
        String sql = "SELECT club_id, name, place FROM club";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                clubs.add(new Club(
                        rs.getInt("club_id"),
                        rs.getString("name"),
                        rs.getString("place")
                ));
            }
        }
        return clubs;
    }
}
