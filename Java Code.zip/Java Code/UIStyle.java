import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;


public class UIStyle {

    public static final Color PRIMARY = new Color(41, 98, 255);      // header / accent blue
    public static final Color PRIMARY_DARK = new Color(25, 65, 191);
    public static final Color BG = new Color(245, 247, 250);          // light background
    public static final Color ROW_ALT = new Color(235, 240, 250);     // striped row color
    public static final Color TEXT_DARK = new Color(33, 37, 41);

    public static final Font FONT_TITLE = new Font("Segoe UI", Font.BOLD, 20);
    public static final Font FONT_LABEL = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_FIELD = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FONT_BUTTON = new Font("Segoe UI", Font.BOLD, 13);

    public static class ImagePanel extends JPanel {
        private final Image image;

        public ImagePanel(Image image) {
            super(new BorderLayout());
            this.image = image;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (image == null) return;
            int panelW = getWidth();
            int panelH = getHeight();
            int imgW = image.getWidth(this);
            int imgH = image.getHeight(this);
            if (imgW <= 0 || imgH <= 0) return;

            double scale = Math.max((double) panelW / imgW, (double) panelH / imgH);
            int scaledW = (int) Math.ceil(imgW * scale);
            int scaledH = (int) Math.ceil(imgH * scale);
            int x = (panelW - scaledW) / 2;
            int y = (panelH - scaledH) / 2;

            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BILINEAR);
            g2.drawImage(image, x, y, scaledW, scaledH, this);
            g2.dispose();
        }
    }

    public static JPanel imageBackgroundFromResource(String imageResourceName) {
        Image img = null;
        try {
            java.net.URL url = UIStyle.class.getResource("/" + imageResourceName);
            if (url != null) {
                img = javax.imageio.ImageIO.read(url);
            } else {
                System.err.println("Background image not found on classpath: " + imageResourceName);
            }
        } catch (Exception e) {
            System.err.println("Could not load background image '" + imageResourceName + "': " + e.getMessage());
        }
        return new ImagePanel(img);
    }
        public static JPanel imageBackgroundFromMain(String imageResourceName) {
        Image img = null;
        try {
            java.net.URL url = UIStyle.class.getResource("/" + imageResourceName);
            if (url != null) {
                img = javax.imageio.ImageIO.read(url);
            } else {
                System.err.println("Background image not found on classpath: " + imageResourceName);
            }
        } catch (Exception e) {
            System.err.println("Could not load background image '" + imageResourceName + "': " + e.getMessage());
        }
        return new ImagePanel(img);
    }
        
        public static JPanel imageBackgroundFromManage(String imageResourceName) {
        Image img = null;
        try {
            java.net.URL url = UIStyle.class.getResource("/" + imageResourceName);
            if (url != null) {
                img = javax.imageio.ImageIO.read(url);
            } else {
                System.err.println("Background image not found on classpath: " + imageResourceName);
            }
        } catch (Exception e) {
            System.err.println("Could not load background image '" + imageResourceName + "': " + e.getMessage());
        }
        return new ImagePanel(img);
    }

    public static JPanel imageBackground(String imagePath) {
        Image img = null;
        try {
            img = javax.imageio.ImageIO.read(new java.io.File(imagePath));
        } catch (Exception e) {
            System.err.println("Could not load background image '" + imagePath + "': " + e.getMessage());
        }
        return new ImagePanel(img);
    }

    public static class GradientPanel extends JPanel {
        private final Color from;
        private final Color to;

        public GradientPanel(Color from, Color to) {
            super(new BorderLayout());
            this.from = from;
            this.to = to;
        }

        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setPaint(new GradientPaint(0, 0, from, getWidth(), getHeight(), to));
            g2.fillRect(0, 0, getWidth(), getHeight());
            g2.dispose();
        }
    }

    public static JPanel gradientBackground(Color from, Color to) {
        return new GradientPanel(from, to);
    }

    public static void applyGlobalLookAndFeel() {
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
        }
    }

    public static JPanel headerPanel(String title) {
        JPanel panel = new JPanel();
        panel.setBackground(PRIMARY);
        panel.setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));
        panel.setLayout(new BorderLayout());

        JLabel label = new JLabel(title);
        label.setFont(FONT_TITLE);
        label.setForeground(Color.WHITE);
        panel.add(label, BorderLayout.WEST);
        return panel;
    }

    public static void styleButton(JButton button, Color background) {
        button.setFont(FONT_BUTTON);
        button.setBackground(background);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
    }

    public static void styleLabel(JLabel label) {
        label.setFont(FONT_LABEL);
        label.setForeground(TEXT_DARK);
    }

    public static void styleTextField(JTextField field) {
        field.setFont(FONT_FIELD);
        field.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 205, 214)),
                BorderFactory.createEmptyBorder(5, 8, 5, 8)));
    }

    public static void styleComboBox(JComboBox<?> box) {
        box.setFont(FONT_FIELD);
        box.setBackground(Color.WHITE);
    }

    public static void styleTable(JTable table) {
        table.setRowHeight(26);
        table.setFont(FONT_FIELD);
        table.setSelectionBackground(PRIMARY.brighter());
        table.setSelectionForeground(Color.WHITE);
        table.setGridColor(new Color(225, 228, 232));

        JTableHeader header = table.getTableHeader();
        header.setFont(FONT_BUTTON);
        header.setBackground(PRIMARY_DARK);
        header.setForeground(Color.WHITE);
        header.setPreferredSize(new Dimension(0, 32));

        table.setDefaultRenderer(Object.class, new javax.swing.table.DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object value, boolean isSelected,
                                                             boolean hasFocus, int row, int column) {
                Component c = super.getTableCellRendererComponent(t, value, isSelected, hasFocus, row, column);
                if (!isSelected) {
                    c.setBackground(row % 2 == 0 ? Color.WHITE : ROW_ALT);
                }
                return c;
            }
        });
    }


    public static JPanel contentPanel(LayoutManager layout) {
        JPanel panel = new JPanel(layout);
        panel.setOpaque(false);
        panel.setBorder(BorderFactory.createEmptyBorder(15, 20, 15, 20));
        return panel;
    }

    public static DefaultTableModel nonEditableModel(Object[] columns) {
        return new DefaultTableModel(columns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
    }
}