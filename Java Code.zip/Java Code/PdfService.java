

import com.lowagie.text.Chunk;
import com.lowagie.text.Document;
import com.lowagie.text.Element;
import com.lowagie.text.Font;
import com.lowagie.text.FontFactory;
import com.lowagie.text.PageSize;
import com.lowagie.text.Paragraph;
import com.lowagie.text.pdf.PdfContentByte;
import com.lowagie.text.pdf.PdfWriter;

import java.awt.Color;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;


public class PdfService {

    private static final String COLLEGE_NAME = "Mepco Schlenk Engineering College";
    private static final String COLLEGE_SUBTITLE = "(Autonomous), Sivakasi";

    private static final Color BG_COLOR = new Color(178, 235, 242);      // light teal
    private static final Color ACCENT_COLOR = new Color(0, 121, 107);    // dark teal
    private static final Color BADGE_COLOR = new Color(255, 255, 255);   // white badges

    public static File generateEventNotice(String clubName, String inchargeName,
                                            String eventName, String eventDate) throws Exception {
        File file = File.createTempFile("event_notice_", ".pdf");

        Document document = new Document(PageSize.A5);
        PdfWriter writer = PdfWriter.getInstance(document, new FileOutputStream(file));
        document.setMargins(40, 40, 100, 60);
        document.open();

        float pageWidth = document.getPageSize().getWidth();
        float pageHeight = document.getPageSize().getHeight();

        PdfContentByte canvas = writer.getDirectContentUnder();
        canvas.setColorFill(BG_COLOR);
        canvas.rectangle(0, 0, pageWidth, pageHeight);
        canvas.fill();

        drawBadge(canvas, 55, pageHeight - 60, 30, "MSEC");
        drawBadge(canvas, pageWidth - 55, pageHeight - 60, 30, initials(clubName));

        Font collegeFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 14, ACCENT_COLOR);
        Font subtitleFont = FontFactory.getFont(FontFactory.HELVETICA, 10, Color.DARK_GRAY);
        Font clubFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 13, ACCENT_COLOR);
        Font dateFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, Color.DARK_GRAY);
        Font labelFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 12, Color.BLACK);
        Font valueFont = FontFactory.getFont(FontFactory.HELVETICA, 12, Color.BLACK);
        Font titleFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 20, ACCENT_COLOR);
        Font footerFont = FontFactory.getFont(FontFactory.HELVETICA, 9, Color.DARK_GRAY);

        Paragraph collegeHeader = new Paragraph(COLLEGE_NAME, collegeFont);
        collegeHeader.setAlignment(Element.ALIGN_CENTER);
        collegeHeader.setSpacingAfter(2);
        document.add(collegeHeader);

        Paragraph collegeSub = new Paragraph(COLLEGE_SUBTITLE, subtitleFont);
        collegeSub.setAlignment(Element.ALIGN_CENTER);
        collegeSub.setSpacingAfter(20);
        document.add(collegeSub);

        Paragraph clubHeader = new Paragraph(clubName, clubFont);
        clubHeader.setAlignment(Element.ALIGN_CENTER);
        clubHeader.setSpacingAfter(4);
        document.add(clubHeader);

        Paragraph date = new Paragraph(eventDate, dateFont);
        date.setAlignment(Element.ALIGN_CENTER);
        date.setSpacingAfter(20);
        document.add(date);

        Font eyebrowFont = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10, ACCENT_COLOR);
        Paragraph eyebrow = new Paragraph("EVENT NOTICE", eyebrowFont);
        eyebrow.setAlignment(Element.ALIGN_CENTER);
        eyebrow.setSpacingAfter(6);
        document.add(eyebrow);

        Paragraph title = new Paragraph(eventName, titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        title.setSpacingAfter(20);
        document.add(title);

        document.add(row("Club Incharge Faculty:", inchargeName, labelFont, valueFont));
        document.add(row("Event Date:", eventDate, labelFont, valueFont));

        Paragraph spacer = new Paragraph(" ");
        spacer.setSpacingAfter(20);
        document.add(spacer);

        Paragraph incharge = new Paragraph("Faculty In Charge: " + inchargeName, labelFont);
        incharge.setSpacingAfter(30);
        document.add(incharge);

        Paragraph subject = new Paragraph();
        subject.add(new Chunk("Subject: ", footerFont));
        subject.add(new Chunk(clubName + " event notice", footerFont));
        subject.setSpacingAfter(2);
        document.add(subject);

        Paragraph copyTo = new Paragraph("Copy to all HODs, faculty, students via email", footerFont);
        document.add(copyTo);

        document.close();
        return file;
    }

    private static void drawBadge(PdfContentByte canvas, float centerX, float centerY, float radius, String label) throws IOException {
        canvas.saveState();
        canvas.setColorFill(BADGE_COLOR);
        canvas.setColorStroke(ACCENT_COLOR);
        canvas.setLineWidth(1.5f);
        canvas.circle(centerX, centerY, radius);
        canvas.fillStroke();

        canvas.setColorFill(ACCENT_COLOR);
        canvas.beginText();
        canvas.setFontAndSize(com.lowagie.text.pdf.BaseFont.createFont(
                com.lowagie.text.pdf.BaseFont.HELVETICA_BOLD, com.lowagie.text.pdf.BaseFont.CP1252,
                com.lowagie.text.pdf.BaseFont.NOT_EMBEDDED), 8);
        canvas.showTextAligned(Element.ALIGN_CENTER, label, centerX, centerY - 3, 0);
        canvas.endText();
        canvas.restoreState();
    }

    private static String initials(String name) {
        if (name == null || name.trim().isEmpty()) return "CLB";
        StringBuilder sb = new StringBuilder();
        for (String word : name.trim().split("\\s+")) {
            if (!word.isEmpty()) sb.append(Character.toUpperCase(word.charAt(0)));
            if (sb.length() >= 4) break;
        }
        return sb.length() > 0 ? sb.toString() : "CLB";
    }

    private static Paragraph row(String label, String value, Font labelFont, Font valueFont) {
        Paragraph p = new Paragraph();
        p.add(new Chunk(label + " ", labelFont));
        p.add(new Chunk(value != null ? value : "N/A", valueFont));
        p.setSpacingAfter(10);
        return p;
    }
}
