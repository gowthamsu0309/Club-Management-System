import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;


public class EnrollmentForm extends JFrame {

    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private final StudentDAO studentDAO = new StudentDAO();
    private final ClubDAO clubDAO = new ClubDAO();
    private final CurrentUser currentUser;

    private JComboBox<String> studentCombo;
    private JComboBox<String> clubCombo;
    private JTable table;
    private DefaultTableModel tableModel;

    public EnrollmentForm(CurrentUser currentUser) {
        this.currentUser = currentUser;

        setTitle("Student-Club Enrollment");
        setSize(750, 500);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(253, 228, 230), new Color(250, 205, 209)));

        add(UIStyle.headerPanel("Student - Club Enrollment"), BorderLayout.NORTH);

        JPanel center = UIStyle.contentPanel(new BorderLayout(10, 10));
        center.add(buildFormPanel(), BorderLayout.NORTH);
        center.add(buildTablePanel(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        add(buildBackPanel(), BorderLayout.SOUTH);

        loadDropdowns();
        loadIntoTable();
    }

    private JPanel buildBackPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        footer.setOpaque(false);
        JButton backBtn = new JButton("Back");
        UIStyle.styleButton(backBtn, new Color(108, 117, 125));
        backBtn.addActionListener(e -> dispose());
        footer.add(backBtn);
        return footer;
    }

    private JPanel buildFormPanel() {
        JPanel fields = new JPanel(new GridLayout(1, 2, 10, 10));
        fields.setBackground(UIStyle.BG);

        studentCombo = new JComboBox<>();
        clubCombo = new JComboBox<>();
        UIStyle.styleComboBox(studentCombo);
        UIStyle.styleComboBox(clubCombo);

        // Staff can only enroll students into their own club
        clubCombo.setEnabled(currentUser.isAdmin());

        fields.add(labeled("Student", studentCombo));
        fields.add(labeled("Club" + (currentUser.isAdmin() ? "" : " (your club only)"), clubCombo));

        JButton enrollBtn = new JButton("Enroll");
        JButton unenrollBtn = new JButton("Remove Selected Enrollment");
        JButton refreshBtn = new JButton("Refresh");
        UIStyle.styleButton(enrollBtn, new Color(46, 160, 67));
        UIStyle.styleButton(unenrollBtn, new Color(220, 53, 69));
        UIStyle.styleButton(refreshBtn, new Color(108, 117, 125));

        enrollBtn.addActionListener(e -> enrollStudent());
        unenrollBtn.addActionListener(e -> removeSelectedEnrollment());
        refreshBtn.addActionListener(e -> { loadDropdowns(); loadIntoTable(); });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(UIStyle.BG);
        buttonPanel.add(enrollBtn);
        buttonPanel.add(unenrollBtn);
        buttonPanel.add(refreshBtn);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UIStyle.BG);
        wrapper.add(fields, BorderLayout.CENTER);
        wrapper.add(buttonPanel, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel labeled(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(UIStyle.BG);
        JLabel label = new JLabel(labelText);
        UIStyle.styleLabel(label);
        p.add(label, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private JScrollPane buildTablePanel() {
        tableModel = UIStyle.nonEditableModel(new Object[]{"Admission No", "Student Name", "Club ID", "Club Name"});
        table = new JTable(tableModel);
        UIStyle.styleTable(table);
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 228, 232)));
        return scroll;
    }

    private void loadDropdowns() {
        try {
            studentCombo.removeAllItems();
            List<Student> students = studentDAO.getAllStudents();
            for (Student s : students) {
                studentCombo.addItem(s.getAdmissionNo() + " - " + s.getName());
            }

            clubCombo.removeAllItems();
            List<Club> clubs = clubDAO.getAllClubs();
            for (Club c : clubs) {
                if (currentUser.isAdmin() ||
                        (currentUser.getClubId() != null && currentUser.getClubId() == c.getClubId())) {
                    clubCombo.addItem(c.getClubId() + " - " + c.getName());
                }
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void loadIntoTable() {
        try {
            tableModel.setRowCount(0);
            List<String[]> rows = enrollmentDAO.getAllEnrollments(); // view ALL enrollments regardless of role
            for (String[] row : rows) {
                tableModel.addRow(row);
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void enrollStudent() {
        try {
            String studentSel = (String) studentCombo.getSelectedItem();
            String clubSel = (String) clubCombo.getSelectedItem();
            if (studentSel == null || clubSel == null) {
                JOptionPane.showMessageDialog(this, "Add at least one student and one club first.");
                return;
            }
            String admissionNo = studentSel.split(" - ")[0];
            int clubId = Integer.parseInt(clubSel.split(" - ")[0]);

            if (!currentUser.owns(clubId)) {
                JOptionPane.showMessageDialog(this,
                        "You can only enroll students into your own club.",
                        "Not allowed", JOptionPane.WARNING_MESSAGE);
                return;
            }

            enrollmentDAO.enroll(admissionNo, clubId);
            loadIntoTable();
            JOptionPane.showMessageDialog(this, "Enrolled successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void removeSelectedEnrollment() {
        try {
            int row = table.getSelectedRow();
            if (row < 0) {
                JOptionPane.showMessageDialog(this, "Select an enrollment row from the table first.");
                return;
            }
            String admissionNo = tableModel.getValueAt(row, 0).toString();
            int clubId = Integer.parseInt(tableModel.getValueAt(row, 2).toString());

            if (!currentUser.owns(clubId)) {
                JOptionPane.showMessageDialog(this,
                        "You can only remove enrollments from your own club.",
                        "Not allowed", JOptionPane.WARNING_MESSAGE);
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this, "Remove this enrollment?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            enrollmentDAO.unenroll(admissionNo, clubId);
            loadIntoTable();
            JOptionPane.showMessageDialog(this, "Enrollment removed.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void showError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        CurrentUser testAdmin = new CurrentUser(1, "Test Admin", "ADMIN", 1);
        SwingUtilities.invokeLater(() -> new EnrollmentForm(testAdmin).setVisible(true));
    }
}