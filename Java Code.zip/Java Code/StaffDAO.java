
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class StaffDAO {

    public void addStaff(Staff s) throws SQLException {
        String sql = "INSERT INTO staff (name, designation, club_id) VALUES (?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getDesignation());
            if (s.getClubId() != null) ps.setInt(3, s.getClubId());
            else ps.setNull(3, Types.INTEGER);
            ps.executeUpdate();
        }
    }

    public void updateStaff(Staff s) throws SQLException {
        String sql = "UPDATE staff SET name = ?, designation = ?, club_id = ? WHERE staff_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getDesignation());
            if (s.getClubId() != null) ps.setInt(3, s.getClubId());
            else ps.setNull(3, Types.INTEGER);
            ps.setInt(4, s.getStaffId());
            ps.executeUpdate();
        }
    }

    public void deleteStaff(int staffId) throws SQLException {
        String sql = "DELETE FROM staff WHERE staff_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, staffId);
            ps.executeUpdate();
        }
    }

    /** Returns a CurrentUser if credentials match, otherwise null. */
    public CurrentUser login(String username, String password) throws SQLException {
        String sql = "SELECT staff_id, name, role, club_id FROM staff WHERE username = ? AND password = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    int clubId = rs.getInt("club_id");
                    Integer clubIdVal = rs.wasNull() ? null : clubId;
                    return new CurrentUser(rs.getInt("staff_id"), rs.getString("name"),
                            rs.getString("role"), clubIdVal);
                }
                return null;
            }
        }
    }

    public List<Staff> getAllStaff() throws SQLException {
        List<Staff> list = new ArrayList<>();
        String sql = "SELECT staff_id, name, designation, club_id FROM staff";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int clubId = rs.getInt("club_id");
                Integer clubIdVal = rs.wasNull() ? null : clubId;
                list.add(new Staff(rs.getInt("staff_id"), rs.getString("name"),
                        rs.getString("designation"), clubIdVal));
            }
        }
        return list;
    }
}
