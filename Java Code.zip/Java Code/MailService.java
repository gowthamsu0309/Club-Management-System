import java.io.File;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.util.Base64;

public class MailService {

    // TODO: fill these in
    private static final String BREVO_API_KEY = "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";
    private static final String SENDER_EMAIL = "gowthamsu03@gmail.com";
    private static final String SENDER_NAME = "Club Management System";

    private static final String BREVO_ENDPOINT = "https://api.brevo.com/v3/smtp/email";

    public static void sendEventMail(String toEmail, String subject, String bodyText, File attachment)
            throws Exception {

        byte[] fileBytes = Files.readAllBytes(attachment.toPath());
        String base64Content = Base64.getEncoder().encodeToString(fileBytes);

        String json = buildJson(toEmail, subject, bodyText, attachment.getName(), base64Content);

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(BREVO_ENDPOINT))
                .header("accept", "application/json")
                .header("api-key", BREVO_API_KEY)
                .header("content-type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            throw new Exception("Brevo API error (HTTP " + response.statusCode() + "): " + response.body());
        }
    }

    private static String buildJson(String toEmail, String subject, String bodyText,
                                     String fileName, String base64Content) {
        return "{"
                + "\"sender\":{\"name\":\"" + escape(SENDER_NAME) + "\",\"email\":\"" + escape(SENDER_EMAIL) + "\"},"
                + "\"to\":[{\"email\":\"" + escape(toEmail) + "\"}],"
                + "\"subject\":\"" + escape(subject) + "\","
                + "\"textContent\":\"" + escape(bodyText) + "\","
                + "\"attachment\":[{\"content\":\"" + base64Content + "\",\"name\":\"" + escape(fileName) + "\"}]"
                + "}";
    }


    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\r", "")
                .replace("\n", "\\n");
    }
}