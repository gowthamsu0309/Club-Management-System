import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.SQLException;
import java.util.List;

public class StudentForm extends JFrame {

    private final StudentDAO studentDAO = new StudentDAO();
    private final SubscriptionDAO subscriptionDAO = new SubscriptionDAO();
    private final EnrollmentDAO enrollmentDAO = new EnrollmentDAO();
    private final CurrentUser currentUser;

    private JTextField admissionNoField, nameField, departmentField, roleField;
    private JComboBox<String> subscriptionCombo;
    private JTable table;
    private DefaultTableModel tableModel;

    public StudentForm(CurrentUser currentUser) {
        this.currentUser = currentUser;

        setTitle("Student Management");
        setSize(750, 520);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setContentPane(UIStyle.gradientBackground(new Color(224, 247, 229), new Color(200, 240, 210)));

        add(UIStyle.headerPanel("Student Management"), BorderLayout.NORTH);

        JPanel center = UIStyle.contentPanel(new BorderLayout(10, 10));
        center.add(buildFormPanel(), BorderLayout.NORTH);
        center.add(buildTablePanel(), BorderLayout.CENTER);
        add(center, BorderLayout.CENTER);

        add(buildBackPanel(), BorderLayout.SOUTH);

        loadSubscriptionOptions();
        loadIntoTable();
    }

    private JPanel buildBackPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.LEFT, 20, 12));
        footer.setOpaque(false);
        JButton backBtn = new JButton("Back");
        UIStyle.styleButton(backBtn, new Color(108, 117, 125));
        backBtn.addActionListener(e -> dispose());
        footer.add(backBtn);
        return footer;
    }

    private JPanel buildFormPanel() {
        JPanel fields = new JPanel(new GridLayout(2, 3, 10, 10));
        fields.setBackground(UIStyle.BG);

        admissionNoField = new JTextField();
        nameField = new JTextField();
        departmentField = new JTextField();
        roleField = new JTextField();
        subscriptionCombo = new JComboBox<>();
        UIStyle.styleTextField(admissionNoField);
        UIStyle.styleTextField(nameField);
        UIStyle.styleTextField(departmentField);
        UIStyle.styleTextField(roleField);
        UIStyle.styleComboBox(subscriptionCombo);

        fields.add(labeled("Admission No (PK)", admissionNoField));
        fields.add(labeled("Name", nameField));
        fields.add(labeled("Department", departmentField));
        fields.add(labeled("Role", roleField));
        fields.add(labeled("Subscription", subscriptionCombo));
        fields.add(new JLabel());

        JButton addBtn = new JButton("Add");
        JButton updateBtn = new JButton("Update");
        JButton deleteBtn = new JButton("Delete");
        JButton clearBtn = new JButton("Clear");
        UIStyle.styleButton(addBtn, new Color(46, 160, 67));
        UIStyle.styleButton(updateBtn, UIStyle.PRIMARY);
        UIStyle.styleButton(deleteBtn, new Color(220, 53, 69));
        UIStyle.styleButton(clearBtn, new Color(108, 117, 125));

        addBtn.addActionListener(e -> addStudent());
        updateBtn.addActionListener(e -> updateStudent());
        deleteBtn.addActionListener(e -> deleteStudent());
        clearBtn.addActionListener(e -> clearFields());

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 10));
        buttonPanel.setBackground(UIStyle.BG);
        buttonPanel.add(addBtn);
        buttonPanel.add(updateBtn);
        buttonPanel.add(deleteBtn);
        buttonPanel.add(clearBtn);

        JPanel wrapper = new JPanel(new BorderLayout());
        wrapper.setBackground(UIStyle.BG);
        wrapper.add(fields, BorderLayout.CENTER);
        wrapper.add(buttonPanel, BorderLayout.SOUTH);
        return wrapper;
    }

    private JPanel labeled(String labelText, JComponent field) {
        JPanel p = new JPanel(new BorderLayout(0, 4));
        p.setBackground(UIStyle.BG);
        JLabel label = new JLabel(labelText);
        UIStyle.styleLabel(label);
        p.add(label, BorderLayout.NORTH);
        p.add(field, BorderLayout.CENTER);
        return p;
    }

    private JScrollPane buildTablePanel() {
        tableModel = UIStyle.nonEditableModel(new Object[]{"Admission No", "Name", "Department", "Role", "Subscription ID"});
        table = new JTable(tableModel);
        UIStyle.styleTable(table);
        table.getSelectionModel().addListSelectionListener(e -> fillFieldsFromSelectedRow());
        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(225, 228, 232)));
        return scroll;
    }

    private void loadSubscriptionOptions() {
        try {
            subscriptionCombo.removeAllItems();
            subscriptionCombo.addItem("None");
            List<Subscription> subs = subscriptionDAO.getAllSubscriptions();
            for (Subscription s : subs) {
                subscriptionCombo.addItem(s.getSubscriptionId() + " - Rs." + s.getAmount());
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private Integer selectedSubscriptionId() {
        String selected = (String) subscriptionCombo.getSelectedItem();
        if (selected == null || selected.equals("None")) return null;
        return Integer.parseInt(selected.split(" - ")[0]);
    }

    private void selectSubscriptionById(Object idObj) {
        if (idObj == null) {
            subscriptionCombo.setSelectedItem("None");
            return;
        }
        String idStr = idObj.toString();
        for (int i = 0; i < subscriptionCombo.getItemCount(); i++) {
            String item = subscriptionCombo.getItemAt(i);
            if (item.startsWith(idStr + " - ")) {
                subscriptionCombo.setSelectedIndex(i);
                return;
            }
        }
        subscriptionCombo.setSelectedItem("None");
    }

    private void loadIntoTable() {
        try {
            tableModel.setRowCount(0);
            List<Student> students = studentDAO.getAllStudents(); // view ALL students regardless of role
            for (Student s : students) {
                tableModel.addRow(new Object[]{s.getAdmissionNo(), s.getName(), s.getDepartment(),
                        s.getRole(), s.getSubscriptionId()});
            }
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void fillFieldsFromSelectedRow() {
        int row = table.getSelectedRow();
        if (row >= 0) {
            admissionNoField.setText(tableModel.getValueAt(row, 0).toString());
            admissionNoField.setEditable(false);
            nameField.setText(tableModel.getValueAt(row, 1).toString());
            departmentField.setText(tableModel.getValueAt(row, 2).toString());
            roleField.setText(tableModel.getValueAt(row, 3).toString());
            selectSubscriptionById(tableModel.getValueAt(row, 4));
        }
    }

    /** Staff can only modify a student who is enrolled in their own club. */
    private boolean canModifySelected() {
        if (admissionNoField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Select a student from the table first.");
            return false;
        }
        if (currentUser.isAdmin()) return true;

        try {
            boolean inOwnClub = currentUser.getClubId() != null
                    && enrollmentDAO.isStudentInClub(admissionNoField.getText(), currentUser.getClubId());
            if (!inOwnClub) {
                JOptionPane.showMessageDialog(this,
                        "You can only modify students enrolled in your own club.",
                        "Not allowed", JOptionPane.WARNING_MESSAGE);
                return false;
            }
            return true;
        } catch (SQLException e) {
            showError(e);
            return false;
        }
    }

    private void addStudent() {
        try {
            if (admissionNoField.getText().trim().isEmpty() || nameField.getText().trim().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Admission No and Name are required.");
                return;
            }
            Student s = new Student(admissionNoField.getText(), nameField.getText(),
                    departmentField.getText(), roleField.getText(), selectedSubscriptionId());
            studentDAO.addStudent(s);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this,
                    "Student added successfully. Enroll them in a club from the Enrollment screen.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void updateStudent() {
        try {
            if (!canModifySelected()) return;
            Student s = new Student(admissionNoField.getText(), nameField.getText(),
                    departmentField.getText(), roleField.getText(), selectedSubscriptionId());
            studentDAO.updateStudent(s);
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Student updated successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void deleteStudent() {
        try {
            if (!canModifySelected()) return;
            int confirm = JOptionPane.showConfirmDialog(this, "Delete this student?", "Confirm",
                    JOptionPane.YES_NO_OPTION);
            if (confirm != JOptionPane.YES_OPTION) return;

            studentDAO.deleteStudent(admissionNoField.getText());
            loadIntoTable();
            clearFields();
            JOptionPane.showMessageDialog(this, "Student deleted successfully.");
        } catch (SQLException e) {
            showError(e);
        }
    }

    private void clearFields() {
        admissionNoField.setText("");
        admissionNoField.setEditable(true);
        nameField.setText("");
        departmentField.setText("");
        roleField.setText("");
        subscriptionCombo.setSelectedItem("None");
        table.clearSelection();
    }

    private void showError(SQLException e) {
        JOptionPane.showMessageDialog(this, "Database error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void main(String[] args) {
        UIStyle.applyGlobalLookAndFeel();
        CurrentUser testAdmin = new CurrentUser(1, "Test Admin", "ADMIN", 1);
        SwingUtilities.invokeLater(() -> new StudentForm(testAdmin).setVisible(true));
    }
}