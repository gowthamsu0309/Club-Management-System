
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    public void addStudent(Student s) throws SQLException {
        String sql = "INSERT INTO student (admission_no, name, department, role, subscription_id) VALUES (?, ?, ?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getAdmissionNo());
            ps.setString(2, s.getName());
            ps.setString(3, s.getDepartment());
            ps.setString(4, s.getRole());
            if (s.getSubscriptionId() != null) {
                ps.setInt(5, s.getSubscriptionId());
            } else {
                ps.setNull(5, Types.INTEGER);
            }
            ps.executeUpdate();
        }
    }

    public void updateStudent(Student s) throws SQLException {
        String sql = "UPDATE student SET name = ?, department = ?, role = ?, subscription_id = ? WHERE admission_no = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getDepartment());
            ps.setString(3, s.getRole());
            if (s.getSubscriptionId() != null) {
                ps.setInt(4, s.getSubscriptionId());
            } else {
                ps.setNull(4, Types.INTEGER);
            }
            ps.setString(5, s.getAdmissionNo());
            ps.executeUpdate();
        }
    }

    public void deleteStudent(String admissionNo) throws SQLException {
        String sql = "DELETE FROM student WHERE admission_no = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, admissionNo);
            ps.executeUpdate();
        }
    }

    public List<Student> getAllStudents() throws SQLException {
        List<Student> list = new ArrayList<>();
        String sql = "SELECT admission_no, name, department, role, subscription_id FROM student";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int subId = rs.getInt("subscription_id");
                Integer subscriptionId = rs.wasNull() ? null : subId;
                list.add(new Student(
                        rs.getString("admission_no"),
                        rs.getString("name"),
                        rs.getString("department"),
                        rs.getString("role"),
                        subscriptionId
                ));
            }
        }
        return list;
    }
}
