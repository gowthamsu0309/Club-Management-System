import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DiagnosticTest {
    public static void main(String[] args) throws Exception {
        int clubId = args.length > 0 ? Integer.parseInt(args[0]) : 1;

        String sql = "SELECT s.admission_no, s.name, s.department, s.role, s.subscription_id, s.email " +
                "FROM stud_club sc JOIN student s ON sc.admission_no = s.admission_no " +
                "WHERE sc.club_id = ?";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, clubId);
            try (ResultSet rs = ps.executeQuery()) {
                int count = 0;
                while (rs.next()) {
                    System.out.println("admission_no=" + rs.getString(1)
                            + " name=" + rs.getString(2)
                            + " department=" + rs.getString(3)
                            + " role=" + rs.getString(4)
                            + " subscription_id=" + rs.getInt(5) + " (wasNull=" + rs.wasNull() + ")"
                            + " email=" + rs.getString(6));
                    count++;
                }
                System.out.println("Rows read: " + count);
            }
        }
        System.out.println("SUCCESS - no exception thrown.");
    }
}
