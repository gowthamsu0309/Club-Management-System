//import clubmanage.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

public class EventDAO {

    public void addEvent(Event ev) throws SQLException {
        String sql = "INSERT INTO event (name, event_date, club_id) VALUES (?, ?, ?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, ev.getName());
            ps.setString(2, ev.getEventDate());
            if (ev.getClubId() != null) ps.setInt(3, ev.getClubId());
            else ps.setNull(3, Types.INTEGER);
            ps.executeUpdate();
        }
    }

    public void updateEvent(Event ev) throws SQLException {
        String sql = "UPDATE event SET name = ?, event_date = ?, club_id = ? WHERE event_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, ev.getName());
            ps.setString(2, ev.getEventDate());
            if (ev.getClubId() != null) ps.setInt(3, ev.getClubId());
            else ps.setNull(3, Types.INTEGER);
            ps.setInt(4, ev.getEventId());
            ps.executeUpdate();
        }
    }

    public void deleteEvent(int eventId) throws SQLException {
        String sql = "DELETE FROM event WHERE event_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, eventId);
            ps.executeUpdate();
        }
    }

    public List<Event> getAllEvents() throws SQLException {
        List<Event> list = new ArrayList<>();
        String sql = "SELECT event_id, name, event_date, club_id FROM event";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                int clubId = rs.getInt("club_id");
                Integer clubIdVal = rs.wasNull() ? null : clubId;
                list.add(new Event(rs.getInt("event_id"), rs.getString("name"),
                        rs.getString("event_date"), clubIdVal));
            }
        }
        return list;
    }
}
