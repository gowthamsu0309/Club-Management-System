

public class Event {
    private int eventId;
    private String name;
    private String eventDate; // yyyy-MM-dd
    private Integer clubId;

    public Event() {}

    public Event(int eventId, String name, String eventDate, Integer clubId) {
        this.eventId = eventId;
        this.name = name;
        this.eventDate = eventDate;
        this.clubId = clubId;
    }

    public int getEventId() { return eventId; }
    public void setEventId(int eventId) { this.eventId = eventId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getEventDate() { return eventDate; }
    public void setEventDate(String eventDate) { this.eventDate = eventDate; }

    public Integer getClubId() { return clubId; }
    public void setClubId(Integer clubId) { this.clubId = clubId; }
}
