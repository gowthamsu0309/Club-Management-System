USE club_management_system;

-- ============================================
-- STORED PROCEDURE: GetClubMemberCounts
-- Returns every club with its total enrolled student count.
-- Uses LEFT JOIN so clubs with 0 students still show up (as 0), not skipped.
-- ============================================

DROP PROCEDURE IF EXISTS GetClubMemberCounts;

DELIMITER $$

CREATE PROCEDURE GetClubMemberCounts()
BEGIN
    SELECT
        c.club_id,
        c.name AS club_name,
        c.place,
        COUNT(sc.admission_no) AS total_students
    FROM club c
    LEFT JOIN stud_club sc ON c.club_id = sc.club_id
    GROUP BY c.club_id, c.name, c.place
    ORDER BY total_students DESC;
END $$

DELIMITER ;

-- Test it directly in Workbench:
-- CALL GetClubMemberCounts();


-- ============================================
-- BONUS (optional, for extra talking points): FUNCTION
-- Returns the student count for a single given club.
-- ============================================

DROP FUNCTION IF EXISTS GetStudentCountForClub;

DELIMITER $$

CREATE FUNCTION GetStudentCountForClub(p_club_id INT)
RETURNS INT
DETERMINISTIC
READS SQL DATA
BEGIN
    DECLARE student_count INT;
    SELECT COUNT(*) INTO student_count
    FROM stud_club
    WHERE club_id = p_club_id;
    RETURN student_count;
END $$

DELIMITER ;

-- Test it directly in Workbench:
-- SELECT name, GetStudentCountForClub(club_id) AS student_count FROM club;


-- ============================================
-- BONUS (optional, for extra talking points): TRIGGERS
-- Maintains a live member_count column on the club table automatically,
-- updated whenever a student joins or leaves a club (stud_club changes).
-- This demonstrates trigger usage, though the procedure above is what
-- your app actually uses to display the report.
-- ============================================

ALTER TABLE club ADD COLUMN member_count INT DEFAULT 0;

-- Backfill existing counts once, so the column starts accurate
UPDATE club c
SET member_count = (
    SELECT COUNT(*) FROM stud_club sc WHERE sc.club_id = c.club_id
);

DROP TRIGGER IF EXISTS after_enroll_insert;
DROP TRIGGER IF EXISTS after_enroll_delete;

DELIMITER $$

CREATE TRIGGER after_enroll_insert
AFTER INSERT ON stud_club
FOR EACH ROW
BEGIN
    UPDATE club SET member_count = member_count + 1 WHERE club_id = NEW.club_id;
END $$

CREATE TRIGGER after_enroll_delete
AFTER DELETE ON stud_club
FOR EACH ROW
BEGIN
    UPDATE club SET member_count = member_count - 1 WHERE club_id = OLD.club_id;
END $$

DELIMITER ;

-- Test it: enroll/unenroll a student through your app, then run:
-- SELECT club_id, name, member_count FROM club;
