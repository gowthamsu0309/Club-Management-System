-- ============================================
-- Club Management System - Database Schema
-- ============================================

CREATE DATABASE IF NOT EXISTS club_management_system;
USE club_management_system;

-- Subscription details for students
CREATE TABLE subscription (
    subscription_id INT AUTO_INCREMENT PRIMARY KEY,
    amount DECIMAL(10,2) NOT NULL,
    start_date DATE NOT NULL,
    end_date DATE NOT NULL
);

-- Club master table
CREATE TABLE club (
    club_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    place VARCHAR(100)
);

-- Staff who are club incharges (1 club -> many staff)
CREATE TABLE staff (
    staff_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    designation VARCHAR(100),
    club_id INT,
    FOREIGN KEY (club_id) REFERENCES club(club_id)
        ON DELETE SET NULL
);

-- Student master table
CREATE TABLE student (
    admission_no VARCHAR(20) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    department VARCHAR(100),
    role VARCHAR(50),
    subscription_id INT,
    FOREIGN KEY (subscription_id) REFERENCES subscription(subscription_id)
        ON DELETE SET NULL
);

-- Junction table: Student <-> Club (many-to-many)
CREATE TABLE stud_club (
    admission_no VARCHAR(20),
    club_id INT,
    PRIMARY KEY (admission_no, club_id),
    FOREIGN KEY (admission_no) REFERENCES student(admission_no)
        ON DELETE CASCADE,
    FOREIGN KEY (club_id) REFERENCES club(club_id)
        ON DELETE CASCADE
);

-- Events organized by a club (1 club -> many events)
CREATE TABLE event (
    event_id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    event_date DATE,
    club_id INT,
    FOREIGN KEY (club_id) REFERENCES club(club_id)
        ON DELETE CASCADE
);

-- Student participation in events (many-to-many via bridge)
CREATE TABLE student_activity (
    stud_act_id INT AUTO_INCREMENT PRIMARY KEY,
    admission_no VARCHAR(20),
    event_id INT,
    FOREIGN KEY (admission_no) REFERENCES student(admission_no)
        ON DELETE CASCADE,
    FOREIGN KEY (event_id) REFERENCES event(event_id)
        ON DELETE CASCADE
);

-- ============================================
-- Sample data so your demo isn't an empty app
-- ============================================

INSERT INTO subscription (amount, start_date, end_date) VALUES
(500.00, '2026-01-01', '2026-12-31'),
(750.00, '2026-01-01', '2026-12-31');

INSERT INTO club (name, place) VALUES
('Coding Club', 'Block A - Lab 3'),
('Music Club', 'Auditorium'),
('Photography Club', 'Media Room');

INSERT INTO staff (name, designation, club_id) VALUES
('Dr. Ramesh Kumar', 'Assistant Professor', 1),
('Ms. Priya Sharma', 'Associate Professor', 2),
('Mr. Arjun Nair', 'Lecturer', 3);

INSERT INTO student (admission_no, name, department, role, subscription_id) VALUES
('CS2023001', 'Aravind S', 'CSE', 'Member', 1),
('CS2023002', 'Divya R', 'CSE', 'Lead', 2),
('ECE2023001', 'Karthik M', 'ECE', 'Member', 1);

INSERT INTO stud_club (admission_no, club_id) VALUES
('CS2023001', 1),
('CS2023002', 1),
('CS2023002', 2),
('ECE2023001', 3);

INSERT INTO event (name, event_date, club_id) VALUES
('Hackathon 2026', '2026-08-15', 1),
('Annual Music Night', '2026-09-10', 2),
('Photo Walk', '2026-08-20', 3);

INSERT INTO student_activity (admission_no, event_id) VALUES
('CS2023001', 1),
('CS2023002', 1),
('CS2023002', 2);
