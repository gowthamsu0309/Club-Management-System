USE club_management_system;

ALTER TABLE staff ADD COLUMN username VARCHAR(50) UNIQUE;
ALTER TABLE staff ADD COLUMN password VARCHAR(50);
ALTER TABLE staff ADD COLUMN role VARCHAR(20) DEFAULT 'STAFF';

-- Give your existing staff rows login credentials.
-- Make ONE of them an admin (not tied to enforcing club ownership).
UPDATE staff SET username = 'ramesh', password = 'ramesh123', role = 'ADMIN' WHERE staff_id = 1;
UPDATE staff SET username = 'priya',  password = 'priya123',  role = 'STAFF' WHERE staff_id = 2;
UPDATE staff SET username = 'arjun',  password = 'arjun123',  role = 'STAFF' WHERE staff_id = 3;

-- Verify:
SELECT staff_id, name, username, role, club_id FROM staff;
